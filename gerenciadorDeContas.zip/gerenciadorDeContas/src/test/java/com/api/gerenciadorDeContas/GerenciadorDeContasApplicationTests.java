package com.api.gerenciadorDeContas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorDeContasApplicationTests {

	@Test
	void contextLoads() {
	}

}
