package com.api.gerenciadorDeContas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadorDeContasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciadorDeContasApplication.class, args);
	}

}
